# Its a Football Data Angular application.
## To work, it takes json data as input.
### It then parses all the data into a workable web application.