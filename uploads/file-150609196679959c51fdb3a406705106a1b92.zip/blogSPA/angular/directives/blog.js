myApp.directive("postCard",function(){
	var index = 1;
	return {
		restrict : "E", //restricts only to elements
		templateUrl: "views/post-card.html",
		scope : {
			blog : "="
		},
		controller : function($scope){
			console.log("directive scope");
			console.log($scope.blog);
			$scope.cardHead = "This is card " + index++;
		}, //, end controller
			//controllerAs : 

		link : function(scope,element,attrs){

				element.on("mouseover",function(){
				element.children().css("background","#EFF0F1");


			});
			element.on("mouseout",function(){
				element.children().css("background","white");
			})
		}


	}

}); //end card directive