myApp.config(['$routeProvider', function($routeProvider){

	$routeProvider

		.when('/',{

				templateUrl : 'views/index-view.html',
				controller : 'mainController',
				controllerAs : 'myBlog'

			})

		.when('/create',{

				templateUrl : 'views/postCreate-view.html',
				controller : 'blogCreateController',
				controllerAs : 'currentBlog'

			})

		.when('/blog/:blogId',{

			templateUrl     : 'views/post-view.html',
        	controller 		: 'singleBlogController',
        	controllerAs 	: 'singleBlog'

			})

		.when('/edit/:blogId',{

			templateUrl     : 'views/postEdit-view.html',
        	controller 		: 'blogEditController',
        	controllerAs 	: 'currentBlog'

			})
}])