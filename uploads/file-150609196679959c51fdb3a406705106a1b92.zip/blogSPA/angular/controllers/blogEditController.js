myApp.controller('blogEditController',['$http','$routeParams','BlogService',function($http,$routeParams,BlogService) {

  //create a context
  var main = this;


  this.pageHeading = 'Edit Blog Post';
  this.pageSubHeading = 'please edit the field you want to change';

  /*this.getParameterByName = function(name){

      name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
      var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
      results = regex.exec(location.search);
      return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));


  }// end get parameter by name*/

  this.blogId = $routeParams.blogId;
  console.log(this.blogId);


  this.loadBlog = function(){
   
      BlogService.loadBlog(main.blogId)
      .then(function successCallback(response) {
          // this callback will be called asynchronously
          // when the response is available
          //console.log(response);
          main.blog = response.data.data;
          console.log(main.blog);

          main.heading = main.blog.heading;
          main.subHeading = main.blog.subHeading;
          main.bodyHtml = main.blog.bodyHtml;
          main.author = main.blog.author;

        }, function errorCallback(response) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
          alert("some error occurred. Check the console.");
          console.log(response);
        });


  }// end load all blogs
  this.loadBlog();


  this.editPost = function(){

      var myData ={

          heading     : main.heading,
          subHeading  : main.subHeading,
          bodyHtml    : main.bodyHtml,
          author      : main.author


      }

      console.log(myData);
   
      BlogService.editABlog(main.blogId,myData)
      .then(function successCallback(response) {
          // this callback will be called asynchronously
          // when the response is available
          //console.log(response);
          alert("blog edited successfully");
          window.location = '#/blog/'+response.data.data.blogId;
          

        }, function errorCallback(response) {
          // called asynchronously if an error occurs
          // or server returns response with an error status.
          alert("some error occurred. Check the console.");
          console.log(response);
        });


  }// end load all blogs
   


}]);