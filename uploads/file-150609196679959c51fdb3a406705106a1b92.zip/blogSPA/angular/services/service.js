// using service method
// in this method , you will be provided with an instance of the functions
// the object instance becomes the service instance that angular registers
// and injects later to other services and controllers if required

myApp.service('BlogService', function($http){
	
	var baseUrl = "https://projectsapi.edwisor.com/api/blogs";

	this.getAllBlogs = function(){

		return $http.get(baseUrl+'/all')

	} //end get all blogs

	this.loadBlog = function (blogId){
		return $http.get(baseUrl+'/'+blogId)
	} // end create blog

	this.createABlog = function (blogData){
		return $http.post(baseUrl+'/create', blogData)
	} // end create blog

	this.editABlog = function (blogId,blogData){
		return $http.put(baseUrl+'/'+blogId+'/edit', blogData)
	} // end edit blog

	this.deleteBlog = function (blogId){
		return $http.post(baseUrl+'/'+blogId+'/remove', null)
	} // end delete blog
	
});